#include "wumpus.h"

#include <iostream>

using namespace std;

//Wumpus Implementation
