#include "gold.h"

#include <iostream>

using namespace std;

//Gold Implementation
