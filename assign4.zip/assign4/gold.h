#ifndef GOLD_H
#define GOLD_H 

//Gold Interface

#endif