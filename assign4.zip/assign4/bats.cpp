#include "bats.h"

#include <iostream>

using namespace std;

//Bats Implementation
