#include "stalactites.h"

#include <iostream>

using namespace std;

//Stalactites Implementation
