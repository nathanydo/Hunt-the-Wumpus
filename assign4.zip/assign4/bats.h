#ifndef BATS_H
#define BATS_H 

//Bats Interface


#endif