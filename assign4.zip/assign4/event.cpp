#include "event.h"

#include <iostream>

using namespace std;

//Event Implementation
